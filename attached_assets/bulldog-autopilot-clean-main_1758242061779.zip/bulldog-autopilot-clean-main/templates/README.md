﻿Upload your .docx files to Supabase Storage bucket 'templates'.
Route fetches via: \/storage/v1/object/public/templates/<key>.docx\.
Use {snake_case} placeholders only.
